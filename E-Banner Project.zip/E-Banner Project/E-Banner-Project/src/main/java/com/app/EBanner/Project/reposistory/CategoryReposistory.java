package com.app.EBanner.Project.reposistory;



import com.app.EBanner.Project.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryReposistory extends JpaRepository<Category, Integer> {
}
