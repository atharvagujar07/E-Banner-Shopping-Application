package com.app.EBanner.Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EBannerProjectApplication {

	public static void main(String[] args) {

		SpringApplication.run(EBannerProjectApplication.class, args);
		String currentDir = System.getProperty("user.dir");
		System.out.println("Current dir using System:" + currentDir);
	}

}
