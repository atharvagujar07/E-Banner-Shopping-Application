package com.app.EBanner.Project.dto;


import jakarta.persistence.FetchType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Data
public class CustomerDTO {
    private int id;
    private String firstname;
    private  String lastname;
    private  String A1;
    private  String A2;
    private int Product_Id;
    private int pincode;
    private  String city;
    private  String phno;
    private  String email;
}
