package com.app.EBanner.Project.reposistory;


import com.app.EBanner.Project.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerReposistory extends JpaRepository<Customer,Integer> {
}
