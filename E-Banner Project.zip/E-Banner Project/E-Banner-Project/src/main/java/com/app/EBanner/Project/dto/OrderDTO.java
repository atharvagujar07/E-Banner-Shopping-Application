package com.app.EBanner.Project.dto;

public class OrderDTO {
//    private int id;
//    private long product_Id;
//
//    private int customer_Id;
}
