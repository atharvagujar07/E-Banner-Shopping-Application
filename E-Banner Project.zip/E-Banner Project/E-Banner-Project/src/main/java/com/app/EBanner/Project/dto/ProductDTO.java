package com.app.EBanner.Project.dto;

import lombok.Data;

@Data
public class ProductDTO {
    private long id;
    private String name;
    private int CategoryId;
    private double Price;
    private String size;
    private  String color;
    private String description;
    private String imageName;

}
