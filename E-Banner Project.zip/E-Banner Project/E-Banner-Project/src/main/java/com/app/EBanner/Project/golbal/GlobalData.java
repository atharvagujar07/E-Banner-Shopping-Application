package com.app.EBanner.Project.golbal;



import com.app.EBanner.Project.model.Product;

import java.util.ArrayList;
import java.util.List;

public class GlobalData {
    public static List<Product>cart;
    static {
        cart=new ArrayList<>();
    }
}

