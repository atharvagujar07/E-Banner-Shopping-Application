//package com.app.MobileAppProject.reposistory;
//
//import com.app.MobileAppProject.model.Customer;
//import com.app.MobileAppProject.model.Order;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface OrderReposistory extends JpaRepository<Order,Integer> {
//}
