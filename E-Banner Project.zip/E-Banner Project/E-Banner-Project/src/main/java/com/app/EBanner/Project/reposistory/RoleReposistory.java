package com.app.EBanner.Project.reposistory;


import com.app.EBanner.Project.model.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleReposistory extends JpaRepository<Role,Integer> {
}
